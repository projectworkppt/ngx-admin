const User = require('../models/user.model.js');

// Create and Save a new User
exports.create = (req, res) => {
    // Validate request
    if(!req.body.userid) {
        return res.status(400).send({
            message: "User ID can not be empty"
        });
    }
    if(!req.body.username) {
        return res.status(400).send({
            message: "User Name can not be empty"
        });
    }
    if(!req.body.email) {
        return res.status(400).send({
            message: "User Email ID can not be empty"
        });
    }
    if(!req.body.password) {
        return res.status(400).send({
            message: "User Password can not be empty"
        });
    }
    // Create a User
    const user = new User({
        userid: req.body.userid,
        username: req.body.username,
        userlastname: req.body.userlastname,
        email: req.body.email,
        mobileno: req.body.mobileno,
        password: req.body.password
    });

    // Save User in the database
    user.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the User."
        });
    });
};

// Retrieve and return all users from the database.
exports.findAll = (req, res) => {
    User.find()
    .then(user => {
        res.send(user);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving user."
        });
    });
};

/*// Find a single user with a Id
exports.findOne = (req, res) => {
    User.findById(req.params.userid)
    .then(user => {
        if(!user) {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });            
        }
        res.send(user);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });                
        }
        return res.status(500).send({
            message: "Error retrieving user with id " + req.params.userid
        });
    });
};
*/
// Find a single user with a userid
exports.findOne = (req, res) => {
    User.find({userid : req.params.userid})
    .then(user => {
        if(!user) {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });            
        }
        res.send(user);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });                
        }
        return res.status(500).send({
            message: "Error retrieving user with id " + req.params.userid
        });
    });
};

// Update a user identified by the userId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.userid) {
        return res.status(400).send({
            message: "User ID can not be empty"
        });
    }

    // Find user and update it with the request body
    const isEmpty = value =>
        value === undefined ||
        value === null ||
        (typeof value === "object" && Object.keys(value).length === 0) ||
        (typeof value === "string" && value.trim().length === 0);

    const updatedFields = {};
    Object.keys(req.body).forEach(key => {
      if (!isEmpty(req.body[key])) {
        updatedFields[key] = req.body[key];
      }
    });

    User.findOneAndUpdate({userid : req.params.userid}, {
        $set:updatedFields
        /*username: req.body.username|| username,
        userlastname: req.body.userlastname|| userlastname,
        email: req.body.email|| email,
        mobileno: req.body.mobileno|| mobileno,
        password: req.body.password|| password*/
    }, {new: true})
    .then(user => {
        if(!user) {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });
        }
        res.send(user);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });                
        }
        return res.status(500).send({
            message: "Error updating user with id " + req.params.userid
        });
    });
};

// Delete a user with the specified userId in the request
exports.delete = (req, res) => {
    User.findOneAndRemove({userid : req.params.userid})
    .then(user => {
        if(!user) {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });
        }
        res.send({message: "User deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "User not found with id " + req.params.userid
            });                
        }
        return res.status(500).send({
            message: "Could not delete USER with id " + req.params.userid
        });
    });
};
