import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { User } from '../service/user';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Access-Control-Allow-Credentials' : 'true',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, PUT, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With'
  })
};

const apiUrl = 'https://projectworkppt.glitch.me'
//const apiUrl = 'http://localhost:3000/user'

@Injectable({
  providedIn: 'root'
})

export class UserService {

  constructor(private http: HttpClient) { }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      return of(result as T);
    };
  }

  getuser(): Observable<User[]> {
    return this.http.get<User[]>(`${apiUrl}`)
      .pipe(
        tap(user => console.log('fetched user')),
        catchError(this.handleError('getuser', []))
      );
  }

 adduser(user: User): Observable<User> {
    return this.http.post<User>(apiUrl, user, httpOptions).pipe(
     tap((user : User) => console.log(`added user `)),
      catchError(this.handleError<User>('adduser'))
    );
  }

}
