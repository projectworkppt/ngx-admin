import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import * as io from 'socket.io-client';
import { UserService } from '../../service/user.service';
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  //socket = io('http://localhost:4000');

  constructor(private router: Router, private api: UserService, private formBuilder: FormBuilder) { }

  registerForm = new FormGroup({
    userid: new FormControl(''),
    username: new FormControl(''),
    userlastname: new FormControl(''),
    email: new FormControl(''),
    mobileno: new FormControl(''),
    password: new FormControl(''),
  });
  
  isLoadingResults = false;

  ngOnInit(): void {
  
  }

  onFormSubmit() {
    this.isLoadingResults = true;
    this.api.adduser(this.registerForm.value)
      .subscribe((res: any) => {
          const id = res._id;
          this.isLoadingResults = false;
          //this.socket.emit('updatedata', res);
          //this.router.navigate(['/sales-details', id]);
        }, (err: any) => {
          console.log(err);
          this.isLoadingResults = false;
        });
  }

}
