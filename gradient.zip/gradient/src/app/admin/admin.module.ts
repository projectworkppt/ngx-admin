import { NgModule } from '@angular/core';

import { AdminRoutingModule } from './admin-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AdminComponent } from './admin.component';
//import { RegisterComponent } from './register/register.component';

@NgModule({
    declarations: [AdminComponent //, RegisterComponent
    ],
    imports: [AdminRoutingModule,ReactiveFormsModule      
    ]
  })
  export class AdminModule { }