import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../service/user.service';
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private api: UserService, private formBuilder: FormBuilder) { }

  loginForm = new FormGroup({
    email: new FormControl(''),
    password: new FormControl('')
  });
  
  isLoadingResults = false;

  ngOnInit(): void {
  
  } 

  onFormSubmit() {
    this.isLoadingResults = true;
    this.api.getuserbyid(this.loginForm.get('email').value)
      .subscribe((res: any) => {
        //console.log(res[0].email);
        if (this.loginForm.get('password').value == res[0].password)
        { 
          console.log('Loging Sucess'); 
          this.router.navigate(['/admin/dashboard']);
        }
        else
        {console.log('Loging Failed'); }

          const id = res._id;
          this.isLoadingResults = false;
          //this.socket.emit('updatedata', res);
          //this.router.navigate(['/register', id]);
        }, (err: any) => {
          console.log(err);
          this.isLoadingResults = false;
        });
  }
}
