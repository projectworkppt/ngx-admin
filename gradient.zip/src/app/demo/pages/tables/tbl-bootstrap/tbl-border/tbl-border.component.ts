import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tbl-border',
  templateUrl: './tbl-border.component.html',
  styleUrls: ['./tbl-border.component.scss']
})
export class TblBorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
