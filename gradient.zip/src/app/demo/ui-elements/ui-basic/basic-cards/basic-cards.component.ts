import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-cards',
  templateUrl: './basic-cards.component.html',
  styleUrls: ['./basic-cards.component.scss']
})
export class BasicCardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
