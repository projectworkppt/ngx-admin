export class User {
    _id: string;
    userid: string;
    username: string;
    userlastname: string;
    email: string;
    mobileno: number;
    password: string;
  }
  